--
-- Database: `umbrella_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `srv_uristore`
--

CREATE TABLE `srv_uristore` (
  `id` int(11) NOT NULL,
  `original_uri` varchar(55) DEFAULT NULL,
  `short_uri` varchar(55) DEFAULT NULL,
  `date` int(11) NOT NULL,
  `from_user` int(11) NOT NULL,
  `to_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `srv_uristore`
--

INSERT INTO `srv_uristore` (`id`, `original_uri`, `short_uri`, `date`, `from_user`, `to_user`) VALUES
(10, 'ag.ru', 'ag23.ru', 1477890780, 2, 1),
(14, 'ag.ru', 'ag222.ru', 1477891924, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `srv_users`
--

CREATE TABLE `srv_users` (
  `id` int(11) NOT NULL,
  `fname` varchar(55) NOT NULL,
  `lname` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `srv_users`
--

INSERT INTO `srv_users` (`id`, `fname`, `lname`) VALUES
(1, 'User1', 'lname1'),
(2, 'User2', 'lname2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `srv_uristore`
--
ALTER TABLE `srv_uristore`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `srv_users`
--
ALTER TABLE `srv_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `srv_uristore`
--
ALTER TABLE `srv_uristore`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `srv_users`
--
ALTER TABLE `srv_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
